import processing.core.PApplet;

class Main {
  public static void main(String[] args) {
    PApplet.main("Sketch", args);
  }
}