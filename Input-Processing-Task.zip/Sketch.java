import processing.core.PApplet;

public class Sketch extends PApplet {

  public void settings() {
    size(1280, 720);
  }

  public void setup() {
    background(135, 206, 235);
  }

  public void draw() { 
    //changes background also clears the canvas
    if (keyPressed) {
      if (keyCode == UP) {
        background(255, 0, 0);
      }
      else if (keyCode == DOWN) {
        background(255, 255, 0);
      }
      else if (keyCode == LEFT) {
        background(255, 165, 0);
      }
      else if (keyCode == RIGHT) {
        background(255, 192, 203);
      }
      else if (keyCode == ALT) {
        background(135, 206, 235);
      }
      else if (keyCode == CONTROL) {
        background(0);
      }
    }
    if (mousePressed) { //creates a tree
    //leaves
    fill(111,78,55);
    rect(mouseX+5,mouseY-15,10,100);
    //trunk
    fill(53,136,86);
    ellipse(mouseX,mouseY,100,95);
    }
  }

  public void mouseDragged() { //creates grass when mouse is dragged
    //creates dirt block
    fill(71, 52, 1);
    rect(mouseX, mouseY, 45, 45);
    //creates grass patch
    fill(30, 121, 44);
    rect(mouseX, mouseY, 45, 15);
  }
  
  public void mouseWheel() { //butterfly
    //wings
    fill(255, 165, 0);
    ellipse(mouseX+5, mouseY-10, 12, 20);
    ellipse(mouseX-5, mouseY-10, 12, 20);
    ellipse(mouseX+5, mouseY+9, 8, 20);
    ellipse(mouseX-5, mouseY+9, 8, 20);
    //butterfly
    fill(71, 52, 1);
    ellipse(mouseX, mouseY, 4, 30);
  }

  public void mouseClicked() { //draws a flower is mouse is pressed
    //stem
    fill(30, 121, 44);
    ellipse(mouseX+10, mouseY+25, 20, 6);
    rect(mouseX-3, mouseY+10, 5, 45);
    //petals
    fill(255, 3, 0);
    ellipse(mouseX-9, mouseY-9, 20, 20);
    ellipse(mouseX+9, mouseY-9, 20, 20);
    ellipse(mouseX-9, mouseY+9, 20, 20);
    ellipse(mouseX+9, mouseY+9, 20, 20);
    //center of flower
    fill(92, 64, 51);
    ellipse(mouseX, mouseY, 10, 10);
  }
}